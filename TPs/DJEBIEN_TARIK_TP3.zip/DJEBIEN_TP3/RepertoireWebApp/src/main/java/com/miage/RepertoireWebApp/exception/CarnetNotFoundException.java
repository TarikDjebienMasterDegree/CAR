package com.miage.RepertoireWebApp.exception;

public class CarnetNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	public CarnetNotFoundException(){
	}
}
