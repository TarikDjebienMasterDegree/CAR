package com.miage.RepertoireWebApp.constante;

public class ConfigurationDefault {
	
	public static final String INNET_ADDRESS = "localhost";
	public static final int PORT = 6789;

}
